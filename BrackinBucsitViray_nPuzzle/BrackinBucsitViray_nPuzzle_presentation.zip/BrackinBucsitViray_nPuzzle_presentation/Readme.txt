This folder contains our backup presentation materials
These 3 html files are the results of our experiment

The plan is to run the program during the presentation which would yeild similar results(3 html files). However, this plan might be too risky due to time constraints so we've prepared these before hand(in case). 