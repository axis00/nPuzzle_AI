This is a python implementation of the n-puzzle

To run the program, the following must be installed on the machine:
python 3
plotly
tqdm

To run the program:
navigate to the directory with puzzle.py and run "py puzzle.py <sample size>"

To test with other puzzle sizes(15,24 ... )
change the GOAL list in puzzle_globals.py
